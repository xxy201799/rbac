package com.xxy.rbac_cloud_upms_biz.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.xxy.rbac.admin.api.entity.SysDict;

import java.util.List;

public interface SysDictService {
    List<SysDict> getByType(LambdaQueryWrapper<SysDict> eq);

    SysDict getById(Integer id);
}
