package com.xxy.rbac_cloud_upms_biz.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.xxy.rbac.admin.api.entity.SysDict;
import com.xxy.rbac.admin.api.entity.SysRole;
import com.xxy.rbac_cloud_upms_biz.mapper.SysDictMapper;
import com.xxy.rbac_cloud_upms_biz.service.SysDictService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class SysMenuServiceImply extends ServiceImpl<SysDictMapper, SysDict> implements SysDictService {
@Autowired
SysDictMapper dictMapper;

    @Override
    public List<SysDict> getByType(LambdaQueryWrapper<SysDict> eq) {

        return  dictMapper.selectList(eq);
    }

    @Override
    public SysDict getById(Integer id) {
        return dictMapper.selectById(id);
    }
}
