package com.xxy.rbac_cloud_upms_biz.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xxy.rbac.admin.api.entity.SysDict;
import com.xxy.rbac.admin.api.entity.SysMenu;

public interface SysDictMapper extends BaseMapper<SysDict> {
}
